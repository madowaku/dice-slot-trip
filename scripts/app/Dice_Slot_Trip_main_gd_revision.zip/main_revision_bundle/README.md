# main.gd 修正版メモ

Roll-to-Move Feel Pass v0.2に合わせた、`main.gd`単体の保守的な修正版です。

## 主な変更

- ロール停止後の時間を定数化
  - SETTLING 140ms
  - RESULT_LOCK 200ms
  - SLOT_TRANSFER 140ms
  - MOVE_PREP 100ms
- 全ダイス停止後に`committed_values`のスナップショットを作成し、その後の表示・役判定・移動へ同じ値を使用
- `_resolve_roll()`開始時に`RESOLVING_TILE`へ早すぎる遷移をせず、実移動完了までは`MOVING`を維持
- 移動完了後に`RESOLVING_TILE`へ遷移
- `_abort_map_dice_roll()`と`_restore_roll_idle()`で明示的に`READY`へ戻し、ハイライト・ホップ・入力除外領域も掃除
- pause中にタイマーが完了しても、即ロール中断せず復帰を待つ
- 5ダイス選択待ちを`RESULT_LOCK`として扱う
- 再開トランザクションの表示フェーズを整理
- 旧19マスを期待していた組み込みQAを8スロット仕様へ更新

## 未検証

この環境にはGodotプロジェクト全体とGodot 4.7実行環境がないため、静的な差分確認と基本的な括弧整合性確認まで実施しています。プロジェクトへ適用後、必ず以下を実行してください。

```powershell
& 'C:\Dev\Tools\Godot-4.7-stable\Godot_v4.7-stable_win64_console.exe' `
  --headless `
  --path . `
  --script tests/run_tests.gd
```

`map_dice_overlay.gd`と`tourism_map_view.gd`側の途中差分が同じブランチにある前提です。
